from __future__ import annotations

import json
import re
from typing import Iterable, List, Optional, Dict, Any, Tuple

from bs4 import BeautifulSoup

from app.core.http import HttpClient
from app.core.utils import clean_text, to_absolute_url, guess_brand, guess_mpn, guess_model
from app.models import Product
from app.sites.base import SiteScraper
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse


class PcGarageScraper(SiteScraper):
    BASE_URL = "https://www.pcgarage.ro"

    CATEGORY_URLS = {
        # conform linkului tău
        "laptopuri": "https://www.pcgarage.ro/notebook-laptop/",
    }

    DETAIL_HREF_RE = re.compile(r"^/notebook-laptop/[^/]+/.+/?$", re.IGNORECASE)

    def __init__(self, http: HttpClient):
        super().__init__(http)

    def iter_listing_urls(self, category: str, max_pages: int) -> Iterable[str]:
        base = self.CATEGORY_URLS.get(category)
        if not base:
            raise ValueError(f"Unknown category '{category}' for PCGarage.")

        yield base

        for p in range(2, max_pages + 1):
            base_slash = base if base.endswith("/") else base + "/"
            yield f"{base_slash}pagina{p}/"

    def parse_listing_page(self, html: str) -> List[str]:
        soup = BeautifulSoup(html, "lxml")
        urls: set[str] = set()

        for a in soup.select(".product_box_name a[href]"):
            href = a.get("href") or ""
            if not href:
                continue

            # absolut + normalizare
            abs_url = href if href.startswith("http") else to_absolute_url(self.BASE_URL, href)
            if not abs_url:
                continue

            p = urlparse(abs_url)

            # acceptă strict doar domeniul pcgarage
            if p.netloc and p.netloc != "www.pcgarage.ro":
                continue

            # filtrează strict doar pagini de produs laptop
            path = p.path or ""
            if not self.DETAIL_HREF_RE.search(path):
                continue

            # scoate query + fragment și normalizează trailing slash
            cleaned = urljoin(self.BASE_URL, path)
            if not cleaned.endswith("/"):
                cleaned += "/"

            urls.add(cleaned)

        return sorted(urls)

    def parse_detail_page(self, html: str, url: str, category: str) -> Product:
        soup = BeautifulSoup(html, "lxml")

        title = self._extract_title(soup) or "UNKNOWN"
        model_guess = guess_model(title)
        price, currency = self._extract_price_and_currency(soup)
        availability = self._extract_availability(soup)
        desc_text, desc_html = self._extract_description(soup)
        specs_raw = self._extract_specs(soup)
        brand = guess_brand(title)
        posted_at = None # PC Garage nu oferă "data publicării"; nu folosim timpul scrape-ului

        mpn = None
        if specs_raw:
            mpn = specs_raw.get("Cod producator") or specs_raw.get("Cod producător")
        if not mpn:
            mpn = guess_mpn(title) or guess_mpn(desc_text)

        return Product(
            source="pcgarage",
            category=category,
            url=url,
            title=title,
            price=price,
            currency=currency or "RON",
            availability=availability,
            condition="nou",
            posted_at=posted_at,
            description_text=desc_text,
            description_html=desc_html,
            model_guess=model_guess,
            brand_guess=brand,
            mpn_guess=mpn,
            specs_raw=specs_raw if specs_raw else None,
        )

    @staticmethod
    def _extract_title(soup: BeautifulSoup) -> Optional[str]:
        h1 = soup.find("h1")
        if h1:
            t = clean_text(h1.get_text(" ", strip=True))
            if t:
                return t

        og = soup.find("meta", attrs={"property": "og:title"})
        if og and og.get("content"):
            t = clean_text(og.get("content"))
            if t:
                return t

        return None

    @staticmethod
    def _iter_jsonld_objects(soup: BeautifulSoup) -> Iterable[Dict[str, Any]]:
        for s in soup.find_all("script", attrs={"type": re.compile(r"application/ld\+json", re.I)}):
            raw = (s.string or s.get_text(strip=True) or "").strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                continue

            if isinstance(data, dict):
                yield data
            elif isinstance(data, list):
                for it in data:
                    if isinstance(it, dict):
                        yield it

    def _extract_price_and_currency(self, soup: BeautifulSoup) -> Tuple[Optional[str], Optional[str]]:
        # 1) JSON-LD: suportă @graph + Product/Offer/AggregateOffer + @type list
        def iter_objs(obj):
            if isinstance(obj, dict):
                yield obj
                if "@graph" in obj and isinstance(obj["@graph"], list):
                    for g in obj["@graph"]:
                        yield from iter_objs(g)
            elif isinstance(obj, list):
                for it in obj:
                    yield from iter_objs(it)

        for obj in self._iter_jsonld_objects(soup):
            for o in iter_objs(obj):
                t = o.get("@type") or ""
                if isinstance(t, list):
                    t = " ".join(map(str, t))
                t_low = str(t).lower()

                # Product -> offers
                if "product" in t_low:
                    offers = o.get("offers")
                    price, cur = self._offers_to_price_currency(offers)
                    if price is not None:
                        return price, cur

                # Offer direct
                if "offer" in t_low:
                    price = o.get("price") or o.get("lowPrice") or o.get("highPrice")
                    cur = o.get("priceCurrency")
                    if price is not None:
                        return str(price), (str(cur) if cur else None)

        # 2) meta itemprop=price (+ currency)
        meta_price = soup.find(attrs={"itemprop": "price"})
        if meta_price:
            content = meta_price.get("content") or meta_price.get("value") or meta_price.get_text(" ", strip=True)
            if content:
                cur = None
                meta_cur = soup.find(attrs={"itemprop": "priceCurrency"})
                if meta_cur:
                    cur = meta_cur.get("content") or meta_cur.get("value") or meta_cur.get_text(" ", strip=True)
                return clean_text(content), (clean_text(cur) if cur else "RON")

        # 3) OpenGraph product:price:amount / currency
        og_amount = soup.find("meta", attrs={"property": re.compile(r"product:price:amount", re.I)})
        if og_amount and og_amount.get("content"):
            og_cur = soup.find("meta", attrs={"property": re.compile(r"product:price:currency", re.I)})
            cur = og_cur.get("content") if og_cur else "RON"
            return clean_text(og_amount.get("content")), clean_text(cur) if cur else "RON"

        # 4) Selectori vizibili (mai mulți)
        for sel in [
            ".ps_price .price_num",
            ".ps_price .price",
            ".ps_price",
            ".price_num",
            ".price",
            "[data-price]",
            "[itemprop='price']",
        ]:
            node = soup.select_one(sel)
            if node:
                if node.has_attr("data-price"):
                    return clean_text(str(node.get("data-price"))), "RON"
                txt = clean_text(node.get_text(" ", strip=True))
                if txt:
                    # păstrează doar numere/virgulă/punct/spații
                    m = re.search(r"(\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)", txt)
                    if m:
                        return clean_text(m.group(1)), "RON"

        # 5) fallback regex pe tot textul
        text = soup.get_text(" ", strip=True)
        m = re.search(r"(\d{1,3}(?:[\s\.]\d{3})*(?:[\.,]\d{2})?)\s*(lei|ron)\b", text, re.IGNORECASE)
        if m:
            return clean_text(m.group(1)), "RON"

        return None, None

    @staticmethod
    def _extract_specs(soup: BeautifulSoup) -> Dict[str, Any]:
        specs: Dict[str, Any] = {}
        selectors = [
            "#software-specifications-table",
            "#specificatii",
            ".product-specs",
            "table",
        ]

        for sel in selectors:
            table = soup.select_one(sel)
            if not table:
                continue

            rows = table.find_all("tr")
            kv_count = 0
            for tr in rows:
                tds = tr.find_all(["td", "th"])
                if len(tds) == 2:
                    k = clean_text(tds[0].get_text(" ", strip=True))
                    v = clean_text(tds[1].get_text(" ", strip=True))
                    if k and v:
                        specs[k] = v
                        kv_count += 1

            if kv_count >= 5:
                return specs

        return specs

    @staticmethod
    def _extract_description(soup: BeautifulSoup) -> Tuple[Optional[str], Optional[str]]:
        # 1) încearcă din JSON-LD (de obicei are description la Product)
        try:
            for obj in PcGarageScraper._iter_jsonld_objects(soup):
                # uneori e @graph
                stack = [obj]
                while stack:
                    o = stack.pop()
                    if isinstance(o, dict):
                        t = o.get("@type") or ""
                        if isinstance(t, list):
                            t = " ".join(map(str, t))
                        if "product" in str(t).lower():
                            d = o.get("description")
                            if d:
                                d_clean = clean_text(str(d))
                                if d_clean:
                                    return d_clean, None
                        if "@graph" in o and isinstance(o["@graph"], list):
                            stack.extend(o["@graph"])
                    elif isinstance(o, list):
                        stack.extend(o)
        except Exception:
            pass

        # 2) meta description / og:description (fallback decent)
        for meta in (
            soup.find("meta", attrs={"property": "og:description"}),
            soup.find("meta", attrs={"name": "description"}),
        ):
            if meta and meta.get("content"):
                d = clean_text(meta.get("content"))
                if d:
                    return d, None

        # 3) containere HTML (mai multe variante posibile)
        selectors = [
            "#product-description-container",
            "#product_description",
            "#tab-description",
            "#tab_descriere",
            "#descriere",
            ".product-description",
            ".produsDescriere",
            ".product-info-description",
            ".product_info_description",
            ".tab-content .description",
            ".tab-pane#description",
            ".tab-pane#descriere",
        ]

        for sel in selectors:
            node = soup.select_one(sel)
            if node:
                txt = clean_text(node.get_text(" ", strip=True))
                node_html = str(node)
                if txt:
                    return txt, node_html

        return None, None
    
    @staticmethod
    def _extract_availability(soup: BeautifulSoup) -> Optional[str]:
        # 1) JSON-LD: Offer.availability
        for obj in PcGarageScraper._iter_jsonld_objects(soup):
            if not isinstance(obj, dict):
                continue
            offers = obj.get("offers")
            if isinstance(offers, dict):
                av = offers.get("availability")
                if isinstance(av, str) and av:
                    # ex: "http://schema.org/InStock"
                    return av.rsplit("/", 1)[-1]
            elif isinstance(offers, list):
                for off in offers:
                    if isinstance(off, dict):
                        av = off.get("availability")
                        if isinstance(av, str) and av:
                            return av.rsplit("/", 1)[-1]

        # 2) DOM fallback (best effort, nu strict)
        text = soup.get_text(" ", strip=True).lower()
        if "in stoc" in text:
            return "InStock"
        if "stoc epuizat" in text or "indisponibil" in text:
            return "OutOfStock"
        if "precomanda" in text or "precomand" in text:
            return "PreOrder"
        return None

    @staticmethod
    def _offers_to_price_currency(offers) -> tuple[str | None, str | None]:
        """
        Normalizează structura schema.org offers (dict sau list).
        Returnează (price_str, currency) sau (None, None).
        """
        if not offers:
            return None, None

        def _pick(o: dict) -> tuple[str | None, str | None]:
            if not isinstance(o, dict):
                return None, None
            price = o.get("price") or o.get("lowPrice") or o.get("highPrice")
            cur = o.get("priceCurrency")
            if price is None:
                return None, None
            return str(price), (str(cur) if cur else "RON")

        if isinstance(offers, dict):
            return _pick(offers)

        if isinstance(offers, list):
            for off in offers:
                price, cur = _pick(off)
                if price is not None:
                    return price, cur

        return None, None